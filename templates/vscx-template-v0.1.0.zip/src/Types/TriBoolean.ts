export type TriBoolean = true | false | "partial";
